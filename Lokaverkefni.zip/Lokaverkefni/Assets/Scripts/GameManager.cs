﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour {

    protected LineRenderer line;
    protected WhiteBall WhiteBall;
    public static int shots;
    public static int ballsLeft = 15;
    public Text shotText;
    public Text ballsLeftText;
    protected RedBall[] balls;

    // Use this for initialization
    void Start () {
        line = FindObjectOfType<LineRenderer>();
        WhiteBall = FindObjectOfType<WhiteBall>();
        shotText.text = "Shots: " + shots;
        ballsLeftText.text = "Pool balls left: " + ballsLeft;
        balls = FindObjectsOfType<RedBall>();
    }
	
	// Update is called once per frame
	void Update () {
        if (ballsLeft == 0)
        {
            SceneManager.LoadScene(2);
        }
        RaycastHit hit;
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        var direction = Vector3.zero;

        if (Physics.Raycast(ray, out hit))
        {
            var ballPos = new Vector3(WhiteBall.transform.position.x, 0.1f, WhiteBall.transform.position.z);
            var mousePos = new Vector3(hit.point.x, 0.1f, hit.point.z);
            line.SetPosition(0, mousePos);
            line.SetPosition(1, ballPos);
            direction = (mousePos - ballPos).normalized;
        }

        if (Input.GetMouseButtonDown(0) && line.gameObject.activeSelf)
        {
            shots++;
            shotText.text = "Shots: " + shots;
            line.gameObject.SetActive(false);
            WhiteBall.GetComponent<Rigidbody>().velocity = direction * 15f;
        }

        if (!line.gameObject.activeSelf && WhiteBall.GetComponent<Rigidbody>().velocity.magnitude < 0.3f)
        {
            line.gameObject.SetActive(true);
        }
        
        ballsLeftText.text = "Pool balls left: " + ballsLeft;
    }

    public static void BallsInHoles()
    {
        ballsLeft -= 1;
    }

    public void Reset()
    {
        WhiteBall.ResetBall();
        foreach (var ball in balls)
        {
            ball.gameObject.SetActive(true);
            ball.ResetBall();
        }
        shots = 0;
    }

}
