﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hornvasar : MonoBehaviour {


    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }

    void OnTriggerEnter(Collider other)
    {
        if (other.name == "Red Ball")
        {
            Debug.Log("Object Exited The Trigger");
            GameManager.BallsInHoles();
        }
    }
}

